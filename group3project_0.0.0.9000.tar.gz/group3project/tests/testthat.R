library(testthat)
library(group3project)

test_check("group3project")
